`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/17/2026 01:50:50 PM
// Design Name: 
// Module Name: flopr_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


`timescale 1ns/1ps  // Step 1: Define simulation time units and precision

module flopr_tb;

    // Step 2: Parameter for DUT width
    parameter int WIDTH = 8;

    // Step 3: Declare testbench signals
    logic clk;
    logic reset;
    logic [WIDTH-1:0] d;
    logic [WIDTH-1:0] q;

    // Step 4: Instantiate the DUT (Device Under Test)
    flopr #(.WIDTH(WIDTH)) dut (
        .clk(clk),
        .reset(reset),
        .d(d),
        .q(q)
    );

    // Step 5: Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;  // Toggle clock every 5 ns → 100 MHz
    end

    // Step 6: Stimulus generation
    initial begin
        // Initialize signals
        reset = 1;
        d = '0;

        // Apply reset for a few cycles
        #12 reset = 0;  // Release reset after 12 ns

        // Drive some values into 'd'
        #10 d = 8'hA5;  // Hex value A5
        #10 d = 8'h3C;  // Hex value 3C
        #10 d = 8'hFF;  // Hex value FF

        // Trigger reset again mid-operation
        #7 reset = 1;
        #10 reset = 0;

        // More values after reset
        #10 d = 8'h55;
        #10 d = 8'h99;

        // End simulation
        #20 $finish;
    end

endmodule

