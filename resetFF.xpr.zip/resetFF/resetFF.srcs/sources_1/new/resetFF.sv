`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/17/2026 01:34:36 PM
// Design Name: 
// Module Name: resetFF
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module flopr #(parameter WIDTH=8)
    (input logic clk,reset,
    input logic[WIDTH-1:0]d,
    output logic[WIDTH-1:0]q);

   always_ff@(posedge clk, posedge reset)
    if(reset) q<=0;
    else      q<=d;
endmodule
