`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/17/2026 01:56:42 PM
// Design Name: 
// Module Name: ShifterTB
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module ShifterTB();

    logic [31:0] a;
    logic [31:0] y;

    // Instantiate the Shifter module
    Shifter dut (
        .a(a),
        .y(y)
    );

    initial begin

        // Test 1
        a = 32'h00000001;
        #10;

        // Test 2
        a = 32'h00000002;
        #10;

        // Test 3
        a = 32'h00000004;
        #10;

        // Test 4
        a = 32'h00000010;
        #10;

        // Test 5
        a = 32'h000000FF;
        #10;

        // Test 6
        a = 32'h0000000A;
        #10;

        // Test 7: Test shifting higher bits
        a = 32'h80000000;
        #10;

        // Test 8: Test all bits set
        a = 32'hFFFFFFFF;
        #10;

        // Test 9: Test zero
        a = 32'h00000000;
        #10;

        $finish;
    end

endmodule
