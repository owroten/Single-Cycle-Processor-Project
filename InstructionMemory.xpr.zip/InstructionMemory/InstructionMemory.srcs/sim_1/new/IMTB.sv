`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/30/2026 12:03:51 PM
// Design Name: 
// Module Name: IMTB
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module IMTB();
logic [5:0] a;
    logic [31:0] rd;

    IM dut(
        .a(a),
        .rd(rd)
    );

    initial begin
    a = 0;
    #10;

    a = 1;
    #10;

    a = 2;
    #10;

    a = 3;
    #10;

    a = 4;
    #10;

    a = 5;
    #10;

    $finish;
end

endmodule