
## Nexys A7-100T Constraints
## Data Memory (dmem)

## Clock - 100 MHz
set_property PACKAGE_PIN E3 [get_ports clk]
set_property IOSTANDARD LVCMOS33 [get_ports clk]
create_clock -period 10.000 -name sys_clk [get_ports clk]

## Write Enable - SW0
set_property PACKAGE_PIN J15 [get_ports we]
set_property IOSTANDARD LVCMOS33 [get_ports we]

## Memory Address - SW1 to SW6
set_property PACKAGE_PIN L16 [get_ports {addr[0]}]
set_property PACKAGE_PIN M13 [get_ports {addr[1]}]
set_property PACKAGE_PIN R15 [get_ports {addr[2]}]
set_property PACKAGE_PIN R17 [get_ports {addr[3]}]
set_property PACKAGE_PIN T18 [get_ports {addr[4]}]
set_property PACKAGE_PIN U18 [get_ports {addr[5]}]
set_property IOSTANDARD LVCMOS33 [get_ports {addr[*]}]

## Write Data - SW7 to SW14
set_property PACKAGE_PIN R13 [get_ports {data_in[0]}]
set_property PACKAGE_PIN T8  [get_ports {data_in[1]}]
set_property PACKAGE_PIN U8  [get_ports {data_in[2]}]
set_property PACKAGE_PIN R16 [get_ports {data_in[3]}]
set_property PACKAGE_PIN T13 [get_ports {data_in[4]}]
set_property PACKAGE_PIN H6  [get_ports {data_in[5]}]
set_property PACKAGE_PIN U12 [get_ports {data_in[6]}]
set_property PACKAGE_PIN U11 [get_ports {data_in[7]}]
set_property IOSTANDARD LVCMOS33 [get_ports {data_in[*]}]

## Read Data - LED0 to LED7
set_property PACKAGE_PIN H17 [get_ports {data_out[0]}]
set_property PACKAGE_PIN K15 [get_ports {data_out[1]}]
set_property PACKAGE_PIN J13 [get_ports {data_out[2]}]
set_property PACKAGE_PIN N14 [get_ports {data_out[3]}]
set_property PACKAGE_PIN R18 [get_ports {data_out[4]}]
set_property PACKAGE_PIN V17 [get_ports {data_out[5]}]
set_property PACKAGE_PIN U17 [get_ports {data_out[6]}]
set_property PACKAGE_PIN U16 [get_ports {data_out[7]}]
set_property IOSTANDARD LVCMOS33 [get_ports {data_out[*]}]
