`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/30/2026 01:09:24 PM
// Design Name: 
// Module Name: dmem_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module dmem_tb;

    // Inputs
    logic clk;
    logic we;
    logic [31:0] a;
    logic [31:0] wd;

    // Output
    logic [31:0] rd;

    // Instantiate the Data Memory module
    dmem dut (
        .clk(clk),
        .we(we),
        .a(a),
        .wd(wd),
        .rd(rd)
    );

    // Generate clock (10 ns period)
    always #5 clk = ~clk;

    initial begin
        // Initialize inputs
        clk = 0;
        we = 0;
        a = 0;
        wd = 0;

        // Test 1: Write to address 0
        #10;
        we = 1;
        a = 32'd0;
        wd = 32'd25;

        #10;
        we = 0;
        #1;

        // Test 2: Write to address 4
        #10;
        we = 1;
        a = 32'd4;
        wd = 32'd50;

        #10;
        we = 0;
        #1;

        // Test 3: Write to address 8
        #10;
        we = 1;
        a = 32'd8;
        wd = 32'd100;

        #10;
        we = 0;
        #1;

        // Test 4: Read address 0 again
        #10;
        a = 32'd0;
        #1;

        // Test 5: Read address 4 again
        #10;
        a = 32'd4;
        #1;

        // Test 6: Read address 8 again
        #10;
        a = 32'd8;
        #1;

        // End simulation
        #10;
    end

endmodule

