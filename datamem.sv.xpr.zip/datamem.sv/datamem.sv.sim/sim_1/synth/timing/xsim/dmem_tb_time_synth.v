// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2026.1 (win64) Build 6511674 Tue Jun 16 11:02:23 MDT 2026
// Date        : Fri Oct 30 13:53:24 2026
// Host        : The-Matrix running 64-bit major release  (build 9200)
// Command     : write_verilog -mode timesim -nolib -sdf_anno true -force -file
//               C:/Users/Benga/datamem.sv/datamem.sv.sim/sim_1/synth/timing/xsim/dmem_tb_time_synth.v
// Design      : dmem
// Purpose     : This verilog netlist is a timing simulation representation of the design and should not be modified or
//               synthesized. Please ensure that this netlist is used with the corresponding SDF file.
// Device      : xc7a100tcsg324-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps
`define XIL_TIMING

module RAM64X1S_UNIQ_BASE_
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD32
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD33
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD34
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD35
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD36
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD37
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD38
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD39
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD40
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD41
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD42
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD43
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD44
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD45
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD46
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD47
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD48
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD49
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD50
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD51
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD52
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD53
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD54
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD55
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD56
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD57
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD58
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD59
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD60
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD61
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

module RAM64X1S_HD62
   (O,
    A0,
    A1,
    A2,
    A3,
    A4,
    A5,
    D,
    WCLK,
    WE);
  output O;
  input A0;
  input A1;
  input A2;
  input A3;
  input A4;
  input A5;
  input D;
  input WCLK;
  input WE;

  wire A0;
  wire A1;
  wire A2;
  wire A3;
  wire A4;
  wire A5;
  wire D;
  wire O;
  wire WCLK;
  wire WE;
  wire NLW_SP_WADR6_UNCONNECTED;
  wire NLW_SP_WADR7_UNCONNECTED;

  RAMS64E #(
    .INIT(64'h0000000000000000),
    .IS_CLK_INVERTED(1'b0),
    .RAM_ADDRESS_MASK(2'b11),
    .RAM_ADDRESS_SPACE(2'b11)) 
    SP
       (.ADR0(A0),
        .ADR1(A1),
        .ADR2(A2),
        .ADR3(A3),
        .ADR4(A4),
        .ADR5(A5),
        .CLK(WCLK),
        .I(D),
        .O(O),
        .WADR6(NLW_SP_WADR6_UNCONNECTED),
        .WADR7(NLW_SP_WADR7_UNCONNECTED),
        .WE(WE));
endmodule

(* NotValidForBitStream *)
(* \DesignAttr:TELEMETRY_DATA  = "{\n  \"Design Flow Data\": {\n    \"Design Data\": {\n      \"Design Mode\": \"Project flow\",\n      \"Top Methodology\": \"SystemVerilog\"\n    },\n    \"Synthesis\": {\n      \"Run Time\": \"61.910000 seconds\"\n    }\n  }\n}" *) 
module dmem
   (clk,
    we,
    a,
    wd,
    rd);
  input clk;
  input we;
  input [31:0]a;
  input [31:0]wd;
  output [31:0]rd;

  wire [31:0]a;
  wire [7:2]a_IBUF;
  wire clk;
  wire clk_IBUF;
  wire clk_IBUF_BUFG;
  wire [31:0]rd;
  wire [31:0]rd_OBUF;
  wire [31:0]wd;
  wire [31:0]wd_IBUF;
  wire we;
  wire we_IBUF;

initial begin
 $sdf_annotate("dmem_tb_time_synth.sdf",,,,"tool_control");
end
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "0" *) 
  (* ram_slice_end = "0" *) 
  RAM64X1S_UNIQ_BASE_ RAM_reg_0_63_0_0
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[0]),
        .O(rd_OBUF[0]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "10" *) 
  (* ram_slice_end = "10" *) 
  RAM64X1S_HD32 RAM_reg_0_63_10_10
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[10]),
        .O(rd_OBUF[10]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "11" *) 
  (* ram_slice_end = "11" *) 
  RAM64X1S_HD33 RAM_reg_0_63_11_11
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[11]),
        .O(rd_OBUF[11]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "12" *) 
  (* ram_slice_end = "12" *) 
  RAM64X1S_HD34 RAM_reg_0_63_12_12
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[12]),
        .O(rd_OBUF[12]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "13" *) 
  (* ram_slice_end = "13" *) 
  RAM64X1S_HD35 RAM_reg_0_63_13_13
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[13]),
        .O(rd_OBUF[13]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "14" *) 
  (* ram_slice_end = "14" *) 
  RAM64X1S_HD36 RAM_reg_0_63_14_14
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[14]),
        .O(rd_OBUF[14]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "15" *) 
  (* ram_slice_end = "15" *) 
  RAM64X1S_HD37 RAM_reg_0_63_15_15
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[15]),
        .O(rd_OBUF[15]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "16" *) 
  (* ram_slice_end = "16" *) 
  RAM64X1S_HD38 RAM_reg_0_63_16_16
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[16]),
        .O(rd_OBUF[16]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "17" *) 
  (* ram_slice_end = "17" *) 
  RAM64X1S_HD39 RAM_reg_0_63_17_17
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[17]),
        .O(rd_OBUF[17]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "18" *) 
  (* ram_slice_end = "18" *) 
  RAM64X1S_HD40 RAM_reg_0_63_18_18
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[18]),
        .O(rd_OBUF[18]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "19" *) 
  (* ram_slice_end = "19" *) 
  RAM64X1S_HD41 RAM_reg_0_63_19_19
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[19]),
        .O(rd_OBUF[19]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "1" *) 
  (* ram_slice_end = "1" *) 
  RAM64X1S_HD42 RAM_reg_0_63_1_1
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[1]),
        .O(rd_OBUF[1]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "20" *) 
  (* ram_slice_end = "20" *) 
  RAM64X1S_HD43 RAM_reg_0_63_20_20
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[20]),
        .O(rd_OBUF[20]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "21" *) 
  (* ram_slice_end = "21" *) 
  RAM64X1S_HD44 RAM_reg_0_63_21_21
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[21]),
        .O(rd_OBUF[21]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "22" *) 
  (* ram_slice_end = "22" *) 
  RAM64X1S_HD45 RAM_reg_0_63_22_22
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[22]),
        .O(rd_OBUF[22]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "23" *) 
  (* ram_slice_end = "23" *) 
  RAM64X1S_HD46 RAM_reg_0_63_23_23
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[23]),
        .O(rd_OBUF[23]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "24" *) 
  (* ram_slice_end = "24" *) 
  RAM64X1S_HD47 RAM_reg_0_63_24_24
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[24]),
        .O(rd_OBUF[24]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "25" *) 
  (* ram_slice_end = "25" *) 
  RAM64X1S_HD48 RAM_reg_0_63_25_25
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[25]),
        .O(rd_OBUF[25]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "26" *) 
  (* ram_slice_end = "26" *) 
  RAM64X1S_HD49 RAM_reg_0_63_26_26
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[26]),
        .O(rd_OBUF[26]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "27" *) 
  (* ram_slice_end = "27" *) 
  RAM64X1S_HD50 RAM_reg_0_63_27_27
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[27]),
        .O(rd_OBUF[27]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "28" *) 
  (* ram_slice_end = "28" *) 
  RAM64X1S_HD51 RAM_reg_0_63_28_28
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[28]),
        .O(rd_OBUF[28]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "29" *) 
  (* ram_slice_end = "29" *) 
  RAM64X1S_HD52 RAM_reg_0_63_29_29
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[29]),
        .O(rd_OBUF[29]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "2" *) 
  (* ram_slice_end = "2" *) 
  RAM64X1S_HD53 RAM_reg_0_63_2_2
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[2]),
        .O(rd_OBUF[2]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "30" *) 
  (* ram_slice_end = "30" *) 
  RAM64X1S_HD54 RAM_reg_0_63_30_30
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[30]),
        .O(rd_OBUF[30]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "31" *) 
  (* ram_slice_end = "31" *) 
  RAM64X1S_HD55 RAM_reg_0_63_31_31
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[31]),
        .O(rd_OBUF[31]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "3" *) 
  (* ram_slice_end = "3" *) 
  RAM64X1S_HD56 RAM_reg_0_63_3_3
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[3]),
        .O(rd_OBUF[3]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "4" *) 
  (* ram_slice_end = "4" *) 
  RAM64X1S_HD57 RAM_reg_0_63_4_4
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[4]),
        .O(rd_OBUF[4]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "5" *) 
  (* ram_slice_end = "5" *) 
  RAM64X1S_HD58 RAM_reg_0_63_5_5
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[5]),
        .O(rd_OBUF[5]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "6" *) 
  (* ram_slice_end = "6" *) 
  RAM64X1S_HD59 RAM_reg_0_63_6_6
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[6]),
        .O(rd_OBUF[6]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "7" *) 
  (* ram_slice_end = "7" *) 
  RAM64X1S_HD60 RAM_reg_0_63_7_7
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[7]),
        .O(rd_OBUF[7]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "8" *) 
  (* ram_slice_end = "8" *) 
  RAM64X1S_HD61 RAM_reg_0_63_8_8
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[8]),
        .O(rd_OBUF[8]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  (* INIT = "64'h0000000000000000" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "dmem/RAM_reg" *) 
  (* RTL_RAM_STYLE = "auto" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "9" *) 
  (* ram_slice_end = "9" *) 
  RAM64X1S_HD62 RAM_reg_0_63_9_9
       (.A0(a_IBUF[2]),
        .A1(a_IBUF[3]),
        .A2(a_IBUF[4]),
        .A3(a_IBUF[5]),
        .A4(a_IBUF[6]),
        .A5(a_IBUF[7]),
        .D(wd_IBUF[9]),
        .O(rd_OBUF[9]),
        .WCLK(clk_IBUF_BUFG),
        .WE(we_IBUF));
  IBUF \a_IBUF[2]_inst 
       (.I(a[2]),
        .O(a_IBUF[2]));
  IBUF \a_IBUF[3]_inst 
       (.I(a[3]),
        .O(a_IBUF[3]));
  IBUF \a_IBUF[4]_inst 
       (.I(a[4]),
        .O(a_IBUF[4]));
  IBUF \a_IBUF[5]_inst 
       (.I(a[5]),
        .O(a_IBUF[5]));
  IBUF \a_IBUF[6]_inst 
       (.I(a[6]),
        .O(a_IBUF[6]));
  IBUF \a_IBUF[7]_inst 
       (.I(a[7]),
        .O(a_IBUF[7]));
  BUFG clk_IBUF_BUFG_inst
       (.I(clk_IBUF),
        .O(clk_IBUF_BUFG));
  IBUF clk_IBUF_inst
       (.I(clk),
        .O(clk_IBUF));
  OBUF \rd_OBUF[0]_inst 
       (.I(rd_OBUF[0]),
        .O(rd[0]));
  OBUF \rd_OBUF[10]_inst 
       (.I(rd_OBUF[10]),
        .O(rd[10]));
  OBUF \rd_OBUF[11]_inst 
       (.I(rd_OBUF[11]),
        .O(rd[11]));
  OBUF \rd_OBUF[12]_inst 
       (.I(rd_OBUF[12]),
        .O(rd[12]));
  OBUF \rd_OBUF[13]_inst 
       (.I(rd_OBUF[13]),
        .O(rd[13]));
  OBUF \rd_OBUF[14]_inst 
       (.I(rd_OBUF[14]),
        .O(rd[14]));
  OBUF \rd_OBUF[15]_inst 
       (.I(rd_OBUF[15]),
        .O(rd[15]));
  OBUF \rd_OBUF[16]_inst 
       (.I(rd_OBUF[16]),
        .O(rd[16]));
  OBUF \rd_OBUF[17]_inst 
       (.I(rd_OBUF[17]),
        .O(rd[17]));
  OBUF \rd_OBUF[18]_inst 
       (.I(rd_OBUF[18]),
        .O(rd[18]));
  OBUF \rd_OBUF[19]_inst 
       (.I(rd_OBUF[19]),
        .O(rd[19]));
  OBUF \rd_OBUF[1]_inst 
       (.I(rd_OBUF[1]),
        .O(rd[1]));
  OBUF \rd_OBUF[20]_inst 
       (.I(rd_OBUF[20]),
        .O(rd[20]));
  OBUF \rd_OBUF[21]_inst 
       (.I(rd_OBUF[21]),
        .O(rd[21]));
  OBUF \rd_OBUF[22]_inst 
       (.I(rd_OBUF[22]),
        .O(rd[22]));
  OBUF \rd_OBUF[23]_inst 
       (.I(rd_OBUF[23]),
        .O(rd[23]));
  OBUF \rd_OBUF[24]_inst 
       (.I(rd_OBUF[24]),
        .O(rd[24]));
  OBUF \rd_OBUF[25]_inst 
       (.I(rd_OBUF[25]),
        .O(rd[25]));
  OBUF \rd_OBUF[26]_inst 
       (.I(rd_OBUF[26]),
        .O(rd[26]));
  OBUF \rd_OBUF[27]_inst 
       (.I(rd_OBUF[27]),
        .O(rd[27]));
  OBUF \rd_OBUF[28]_inst 
       (.I(rd_OBUF[28]),
        .O(rd[28]));
  OBUF \rd_OBUF[29]_inst 
       (.I(rd_OBUF[29]),
        .O(rd[29]));
  OBUF \rd_OBUF[2]_inst 
       (.I(rd_OBUF[2]),
        .O(rd[2]));
  OBUF \rd_OBUF[30]_inst 
       (.I(rd_OBUF[30]),
        .O(rd[30]));
  OBUF \rd_OBUF[31]_inst 
       (.I(rd_OBUF[31]),
        .O(rd[31]));
  OBUF \rd_OBUF[3]_inst 
       (.I(rd_OBUF[3]),
        .O(rd[3]));
  OBUF \rd_OBUF[4]_inst 
       (.I(rd_OBUF[4]),
        .O(rd[4]));
  OBUF \rd_OBUF[5]_inst 
       (.I(rd_OBUF[5]),
        .O(rd[5]));
  OBUF \rd_OBUF[6]_inst 
       (.I(rd_OBUF[6]),
        .O(rd[6]));
  OBUF \rd_OBUF[7]_inst 
       (.I(rd_OBUF[7]),
        .O(rd[7]));
  OBUF \rd_OBUF[8]_inst 
       (.I(rd_OBUF[8]),
        .O(rd[8]));
  OBUF \rd_OBUF[9]_inst 
       (.I(rd_OBUF[9]),
        .O(rd[9]));
  IBUF \wd_IBUF[0]_inst 
       (.I(wd[0]),
        .O(wd_IBUF[0]));
  IBUF \wd_IBUF[10]_inst 
       (.I(wd[10]),
        .O(wd_IBUF[10]));
  IBUF \wd_IBUF[11]_inst 
       (.I(wd[11]),
        .O(wd_IBUF[11]));
  IBUF \wd_IBUF[12]_inst 
       (.I(wd[12]),
        .O(wd_IBUF[12]));
  IBUF \wd_IBUF[13]_inst 
       (.I(wd[13]),
        .O(wd_IBUF[13]));
  IBUF \wd_IBUF[14]_inst 
       (.I(wd[14]),
        .O(wd_IBUF[14]));
  IBUF \wd_IBUF[15]_inst 
       (.I(wd[15]),
        .O(wd_IBUF[15]));
  IBUF \wd_IBUF[16]_inst 
       (.I(wd[16]),
        .O(wd_IBUF[16]));
  IBUF \wd_IBUF[17]_inst 
       (.I(wd[17]),
        .O(wd_IBUF[17]));
  IBUF \wd_IBUF[18]_inst 
       (.I(wd[18]),
        .O(wd_IBUF[18]));
  IBUF \wd_IBUF[19]_inst 
       (.I(wd[19]),
        .O(wd_IBUF[19]));
  IBUF \wd_IBUF[1]_inst 
       (.I(wd[1]),
        .O(wd_IBUF[1]));
  IBUF \wd_IBUF[20]_inst 
       (.I(wd[20]),
        .O(wd_IBUF[20]));
  IBUF \wd_IBUF[21]_inst 
       (.I(wd[21]),
        .O(wd_IBUF[21]));
  IBUF \wd_IBUF[22]_inst 
       (.I(wd[22]),
        .O(wd_IBUF[22]));
  IBUF \wd_IBUF[23]_inst 
       (.I(wd[23]),
        .O(wd_IBUF[23]));
  IBUF \wd_IBUF[24]_inst 
       (.I(wd[24]),
        .O(wd_IBUF[24]));
  IBUF \wd_IBUF[25]_inst 
       (.I(wd[25]),
        .O(wd_IBUF[25]));
  IBUF \wd_IBUF[26]_inst 
       (.I(wd[26]),
        .O(wd_IBUF[26]));
  IBUF \wd_IBUF[27]_inst 
       (.I(wd[27]),
        .O(wd_IBUF[27]));
  IBUF \wd_IBUF[28]_inst 
       (.I(wd[28]),
        .O(wd_IBUF[28]));
  IBUF \wd_IBUF[29]_inst 
       (.I(wd[29]),
        .O(wd_IBUF[29]));
  IBUF \wd_IBUF[2]_inst 
       (.I(wd[2]),
        .O(wd_IBUF[2]));
  IBUF \wd_IBUF[30]_inst 
       (.I(wd[30]),
        .O(wd_IBUF[30]));
  IBUF \wd_IBUF[31]_inst 
       (.I(wd[31]),
        .O(wd_IBUF[31]));
  IBUF \wd_IBUF[3]_inst 
       (.I(wd[3]),
        .O(wd_IBUF[3]));
  IBUF \wd_IBUF[4]_inst 
       (.I(wd[4]),
        .O(wd_IBUF[4]));
  IBUF \wd_IBUF[5]_inst 
       (.I(wd[5]),
        .O(wd_IBUF[5]));
  IBUF \wd_IBUF[6]_inst 
       (.I(wd[6]),
        .O(wd_IBUF[6]));
  IBUF \wd_IBUF[7]_inst 
       (.I(wd[7]),
        .O(wd_IBUF[7]));
  IBUF \wd_IBUF[8]_inst 
       (.I(wd[8]),
        .O(wd_IBUF[8]));
  IBUF \wd_IBUF[9]_inst 
       (.I(wd[9]),
        .O(wd_IBUF[9]));
  IBUF we_IBUF_inst
       (.I(we),
        .O(we_IBUF));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
