`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/17/2026 01:44:06 PM
// Design Name: 
// Module Name: Mux2Sim
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module Mux2_TB();
logic[7:0]d0,d1;
logic s;
logic[7:0]y;

mux2#(32) dut(d0,d1,s,y);

initial begin
d0 = 5; d1 = 2; s = 0;
#10;
s = 1;
#10;
end
endmodule
