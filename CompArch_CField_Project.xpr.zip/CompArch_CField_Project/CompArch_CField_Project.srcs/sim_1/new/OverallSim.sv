`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/17/2026 01:53:37 PM
// Design Name: 
// Module Name: OverallSim
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module testbench();
logic clk;
logic reset;
logic[31:0]writedata,dataadr;
logic memwrite;

//instantiatedevicetobetested
top dut(clk,reset,writedata,dataadr,memwrite);

//initializetest
initial begin
reset<=1;#22;reset<=0;
end

//generateclocktosequencetests
always begin
clk<=1;#5;clk<=0;#5;
end

//checkresults
always@(negedge clk)
    begin
    if(memwrite)begin
        if(dataadr==84 && writedata==7)begin
        $display("Simulationsucceeded");
        $stop;
    end else if(dataadr != 80)begin
        $display("Simulationfailed");
        $stop;
        end
    end
end
endmodule
