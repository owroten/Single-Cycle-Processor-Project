`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/17/2026 01:26:25 PM
// Design Name: 
// Module Name: MainDecoderSim
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module MainDecoder_TB();

logic[5:0]op;
logic memtoreg,memwrite,branch,alusrc,regdst,regwrite,jump;
logic[1:0]aluop;

maindec dut(op,memtoreg,memwrite,branch,alusrc,regdst,regwrite,jump,aluop);

initial begin
op = 6'b000000;
#10;
op = 6'b100011;
#10;
op = 6'b101011;
#10;
op = 6'b000100;
#10;
op = 6'b001000;
#10;
op = 6'b000010;
#10;
end
endmodule
