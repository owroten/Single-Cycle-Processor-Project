`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/17/2026 01:34:10 PM
// Design Name: 
// Module Name: SETB
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module SETB();
logic [15:0] a;
    logic [31:0] y;

    SignExtension dut(
        .a(a),
        .y(y)
    );

    initial begin
    // Test 1: Positive number
        a = 16'h0005;
        #10;

        // Test 2: Largest positive number
        a = 16'h7FFF;
        #10;

        // Test 3: Negative number
        a = 16'hFFFF;
        #10;

        // Test 4: Another negative number
        a = 16'h8000;
        #10;

        // Test 5: Negative number
        a = 16'hFF00;
        #10;

        // Test 6: Zero
        a = 16'h0000;
        #10;

        $finish;
    end

endmodule